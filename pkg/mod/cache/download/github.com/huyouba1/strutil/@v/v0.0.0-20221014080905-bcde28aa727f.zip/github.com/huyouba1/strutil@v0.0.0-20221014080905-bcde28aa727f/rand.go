package strutil

func RandString() string {
	return "kk"
}
